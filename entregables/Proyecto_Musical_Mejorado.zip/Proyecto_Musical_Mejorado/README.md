# Segmentación musical — entrega mejorada

Comparación de K-Means y GMM antes y después de PCA. Popularidad como análisis
secundario, sin prometer una fórmula de éxito.

## Abrir primero
1. `resultados/informe.html`: informe único, doce respuestas y todas las evidencias.
2. `Proyecto_Mejorado.ipynb`: código completo, ejecutado y con salidas reales.
3. `resultados/cierre_escucha.html`: dos canciones reales para ilustrar el cierre.

## Reproducir
Desde esta carpeta, con Python 3.12:

```powershell
python -m pip install -r requirements.txt
python mejorar_proyecto.py
```

Alternativa: abrir `Proyecto_Mejorado.ipynb` en un entorno Jupyter y ejecutar
las celdas en orden desde esta carpeta. El cuaderno ejecuta el mismo código
que el script. Con las dependencias instaladas y el CSV incluido, no necesita
internet. Los enlaces de escucha sí requieren conexión y disponibilidad de Spotify.

## Qué cambió
- Selección dentro de las 8.000 canciones de desarrollo: 5.421 para ajuste y
  2.579 para validación, sin artistas individuales compartidos entre ambas.
- Prueba adicional: 2.000 canciones fuera de la muestra previa, sin artistas
  compartidos con esa muestra y sin vectores acústicos iguales a siete decimales.
- Comparación predefinida de StandardScaler y Yeo-Johnson, con PCA en ambos casos.
- Selección orientada a segmentación: separación de validación, tamaño mínimo
  de grupos y parsimonia; BIC/AIC se conservan como diagnóstico de densidad.
- Métricas en geometría común, estabilidad y tiempos repetidos.

## Qué mejoró y qué empeoró
En las mismas 8.000 canciones y geometría de referencia, GMM original pasa de
Silhouette -0,0274 a 0,2326; K-Means original baja de 0,2493 a 0,2024.
La nueva regla cambia el objetivo respecto al BIC anterior: la mejora de GMM
no demuestra mejor densidad ni utilidad perceptiva. La ventaja media de la
transformación en validación es pequeña: aproximadamente 0,0052.
Se informan también los resultados de prueba sin volver a elegir modelos.

No se encontró ni se buscó una característica que garantice éxito comercial.
El cierre musical es ilustrativo: escuchar y contrastar similitud numérica con
percepción. No hay audio descargado ni evaluación humana inventada.

## Diccionario de variables
| Variable | Qué describe | Unidad |
| --- | --- | --- |
| danceability | Bailabilidad estimada | 0–1 |
| energy | Intensidad percibida | 0–1 |
| loudness | Nivel sonoro | dB |
| speechiness | Presencia de habla | 0–1 |
| acousticness | Carácter acústico | 0–1 |
| instrumentalness | Carácter instrumental | 0–1 |
| liveness | Indicios de interpretación en directo | 0–1 |
| valence | Positividad sonora estimada, no emoción del oyente | 0–1 |
| tempo | Velocidad del pulso | BPM |
| duration_ms | Duración | Milisegundos |

## Estructura de la entrega
- `mejorar_proyecto.py`: experimento completo y generación del informe.
- `Proyecto_Mejorado.ipynb`: mismo código visible y ejecutado.
- `protocolo_mejora.json`: alternativas y reglas fijadas antes de la nueva búsqueda.
- `requirements.txt`: versiones exactas del entorno.
- `data/raw/`: fuente original y manifiesto de procedencia.
- `data/referencia_anterior/`: particiones previas para excluir observaciones y
  artistas ya utilizados; tabla previa para la comparación histórica controlada.
- `resultados/`: tablas, figuras, validación, informe y cierre musical.

No se necesitan el laboratorio de marketing, simuladores ni las versiones antiguas
para ejecutar esta entrega. El ZIP final incluye solo los elementos listados arriba.
HTML y Markdown son dos formatos del mismo informe, no informes contradictorios.

## Procedencia y autoría
Fuente: Maharshi Pandya, Spotify Tracks Dataset, Hugging Face.
https://huggingface.co/datasets/maharshipandya/spotify-tracks-dataset
Licencia declarada por su ficha: bsd; no se especifica aquí una variante no documentada.
Completar estudiantes y fecha antes de entregar. Se utilizó ChatGPT/Codex para
implementación, análisis y documentación. Revisar personalmente los resultados y
preparar la defensa. Ninguna implementación garantiza una nota de 100.
