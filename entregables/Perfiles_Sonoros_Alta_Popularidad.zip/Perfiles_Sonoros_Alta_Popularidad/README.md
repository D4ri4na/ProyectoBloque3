# Perfiles sonoros y alta popularidad musical

## Pregunta principal
¿Existen perfiles sonoros que concentren canciones de alta popularidad y qué características los distinguen?

El proyecto busca asociaciones entre perfiles acústicos y popularidad. El clustering
es el método para responder esa pregunta, no un reemplazo del objetivo. No se
pretende demostrar causalidad ni garantizar éxito comercial.

## Qué abrir
1. `resultados/informe.html`: respuesta principal, tablas, gráficos y 12 respuestas.
2. `Proyecto_Mejorado.ipynb`: código de los dos módulos y salidas reales.
3. `resultados/resultado_objetivo.json`: conclusión y cifras del contraste principal.
4. `resultados/cierre_escucha.html`: ejemplo auditivo complementario y sus límites.

## Diseño
1. K-Means y GMM, antes y después de PCA, se ajustan únicamente con diez
   características sonoras. Popularidad no elige preparación, K, covarianza o modelo.
2. Con los modelos congelados, se identifica el perfil con mayor proporción de
   canciones >=70 en entrenamiento. Esta selección posterior sí mira popularidad,
   pero solo en entrenamiento, y no cambia las asignaciones aprendidas.
3. La configuración principal es la ya elegida por Silhouette de validación.
4. Otras 2.000 canciones, sin IDs, artistas ni vectores acústicos exactos compartidos
   con los datos ya utilizados, evalúan la concentración del candidato.
5. Se reportan tasas, lift, diferencia frente al resto, intervalos bootstrap por
   componentes de artistas y sensibilidad con umbrales 60/80.
6. Se describen rasgos del candidato mediante medianas originales, sin atribuir
   efectos causales ni importancia predictiva.

Alta popularidad significa >=70 en el archivo histórico. No equivale a ingresos,
ventas o éxito universal. La evaluación adicional anterior ya observada se presenta
como retrospectiva; la nueva evaluación del objetivo no selecciona modelos.

## Reproducir
Con Python 3.12, desde esta carpeta:

```powershell
python -m pip install -r requirements.txt
python mejorar_proyecto.py
```

El script ejecuta clustering/PCA y después el objetivo de popularidad. Alternativa:
abrir `Proyecto_Mejorado.ipynb` en Jupyter y ejecutar todas las celdas en orden.
Para recalcular solo el objetivo a partir del núcleo ya ejecutado:

```powershell
python analizar_popularidad.py
```

La segunda opción reproduce los cuatro modelos y exige ARI=1 antes de continuar.
No necesita conexión si están instaladas las dependencias y se conserva el CSV.
Los enlaces a canciones requieren internet; no se incluye audio descargado.

## Organización
- `mejorar_proyecto.py`: ajuste sin popularidad, comparación de modelos y PCA.
- `analizar_popularidad.py`: pregunta principal, candidatos, evaluación y publicación.
- `Proyecto_Mejorado.ipynb`: ambos módulos visibles y ejecutados.
- `protocolo_popularidad.json`: objetivo, umbrales y contraste principal.
- `protocolo_mejora.json`: protocolo metodológico previo del núcleo de clustering;
  se preserva para no alterar retroactivamente la selección ya congelada.
- `requirements.txt`: entorno de ejecución.
- `data/raw/`: CSV original y procedencia.
- `data/referencia_anterior/`: registros ya utilizados, necesarios para exclusiones
  y para la comparación metodológica histórica.
- `resultados/`: evidencia numérica, figuras e informe único en HTML y Markdown.

## Qué significan las diez variables
| Variable | Interpretación | Unidad |
| --- | --- | --- |
| danceability | Bailabilidad estimada | 0–1 |
| energy | Intensidad percibida | 0–1 |
| loudness | Nivel sonoro | dB |
| speechiness | Presencia de habla | 0–1 |
| acousticness | Carácter acústico | 0–1 |
| instrumentalness | Carácter instrumental | 0–1 |
| liveness | Indicios de interpretación en directo | 0–1 |
| valence | Positividad sonora estimada | 0–1 |
| tempo | Velocidad del pulso | BPM |
| duration_ms | Duración | Milisegundos |

## Interpretación y límites
No basta con que un perfil tenga más canciones populares en entrenamiento:
debe conservar concentración en la nueva evaluación y mostrar incertidumbre.
Si el contraste no se confirma, ese es el resultado; no se cambia el umbral o
el modelo para obtener una asociación más llamativa. Las cuatro configuraciones
comparten observaciones y no representan confirmaciones independientes.

La fuente es histórica y de conveniencia. Artista, promoción, idioma o exposición
pueden explicar diferencias; no se analizan estructura, melodía o letra. La revisión
fue motivada por resultados previos y no se presenta como prerregistro externo.

Fuente: Pandya, Spotify Tracks Dataset, Hugging Face; licencia declarada: bsd.
https://huggingface.co/datasets/maharshipandya/spotify-tracks-dataset
Se utilizó ChatGPT/Codex para implementación y documentación. Completar autores,
revisar los resultados y declarar la asistencia. No se garantiza una nota de 100.
