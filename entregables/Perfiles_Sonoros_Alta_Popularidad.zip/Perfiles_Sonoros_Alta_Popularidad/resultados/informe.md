# ¿Existen perfiles sonoros que concentren canciones de alta popularidad y qué características los distinguen?

Proyecto de Bloque 3 · Aprendizaje no supervisado · K-Means y GMM antes y después de PCA. Completar autores y fecha de entrega.

## Resumen del resultado

El contraste principal usa KMeans_pca, seleccionado antes por calidad geométrica y sin popularidad. El perfil candidato es el grupo 0, elegido en entrenamiento por su proporción de canciones con popularidad ≥70: 222/5990 (3.71%). En 2.000 canciones adicionales de artistas no utilizados antes, el perfil presenta 45/1529 (2.94%), frente a una tasa global de 2.90%. Su lift es 1.01. No se confirma una mayor concentración en la nueva evaluación: el intervalo de la diferencia incluye cero.

Diferencia frente al resto: +0.18 puntos porcentuales, IC95 por artistas [-1.46, +1.76]. Las características que más distinguen el perfil en entrenamiento son: acousticness: mediana 0.079 frente a 0.819 en el resto; energy: mediana 0.762 frente a 0.299 en el resto; loudness: mediana -6.142 frente a -13.018 en el resto; valence: mediana 0.532 frente a 0.261 en el resto. Son rasgos descriptivos del grupo, no causas del éxito.

## 1. Objetivo y alcance

¿Existen perfiles sonoros que concentren canciones de alta popularidad y qué características los distinguen?

Objetivo general: descubrir perfiles utilizando exclusivamente características sonoras, determinar si alguno concentra canciones de alta popularidad y describir los atributos que lo distinguen. Objetivos específicos: limpiar y preparar datos; comparar K-Means y GMM antes/después de PCA; identificar candidatos en entrenamiento; evaluar concentración en canciones adicionales; comprobar sensibilidad y comunicar límites.

El clustering es el método para responder esta pregunta, no el fin comercial del proyecto. No se convierte el trabajo en un predictor supervisado ni se usa popularidad para escoger algoritmos, preparación, K o covarianza.

## 2. Cómo se define y mide alta popularidad

Definición operativa principal: popularity ≥70 en la escala histórica 0–100 del dataset. No equivale a ventas, ingresos o éxito universal. Los umbrales 60 y 80 son sensibilidad fijada antes de esta evaluación; no se elige el que produzca la mejor historia. Ceros se conservan como valores del archivo, sin interpretarlos como ausencia real de oyentes.

Concentración = canciones ≥70 / canciones con popularidad válida del perfil. Lift = tasa del perfil / tasa global del mismo conjunto: 1 indica igual concentración; 2 significa el doble de la tasa observada, no el doble de probabilidad causal de éxito. La diferencia principal compara perfil y resto, expresada en puntos porcentuales.

Protocolo: algoritmos y parámetros ya estaban congelados por separación geométrica. Para cada una de las cuatro configuraciones se elige el perfil candidato exclusivamente por la mayor tasa ≥70 de entrenamiento, con desempate por ID. El modelo principal se fija por el mayor Silhouette de validación previamente registrado. Se preserva esa elección en sensibilidad, sin seleccionar nuevos perfiles con los resultados de prueba.

## 3. Comprobación en canciones no utilizadas antes

Se reservaron 2000 canciones con semilla 20261121, de 18120 elegibles. Se excluyeron los 10.000 IDs históricos, las 2.000 canciones de la evaluación adicional anterior, todos sus artistas individuales y los vectores acústicos iguales a siete decimales. No se eligieron canciones por su popularidad. La fuente histórica es la misma: no se presenta como evidencia temporal o externa.

La evaluación anterior de 2.000 canciones ya había sido observada y se muestra como retrospectiva. La conclusión principal utiliza la nueva evaluación. La decisión de revisar el objetivo está informada por análisis previos: este protocolo documenta criterios anteriores a este nuevo cálculo, pero no es un prerregistro externo.

![Concentración de alta popularidad por perfil](figuras/concentracion_popularidad.png)

| configuration | split | cluster | threshold | n | high_count | high_rate | global_rate | lift | median | q25 | q75 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| KMeans_original | entrenamiento | 0 | 70 | 5967 | 221 | 0.03704 | 0.03175 | 1.16652 | 34.00000 | 20.00000 | 48.00000 |
| KMeans_original | entrenamiento | 1 | 70 | 2033 | 33 | 0.01623 | 0.03175 | 0.51125 | 29.00000 | 17.00000 | 46.00000 |
| GMM_original | entrenamiento | 0 | 70 | 2755 | 43 | 0.01561 | 0.03175 | 0.49159 | 26.00000 | 16.00000 | 45.00000 |
| GMM_original | entrenamiento | 1 | 70 | 5245 | 211 | 0.04023 | 0.03175 | 1.26705 | 36.00000 | 22.00000 | 49.00000 |
| KMeans_pca | entrenamiento | 0 | 70 | 5990 | 222 | 0.03706 | 0.03175 | 1.16730 | 34.00000 | 20.00000 | 48.00000 |
| KMeans_pca | entrenamiento | 1 | 70 | 2010 | 32 | 0.01592 | 0.03175 | 0.50143 | 29.00000 | 17.00000 | 46.00000 |
| GMM_pca | entrenamiento | 0 | 70 | 2197 | 24 | 0.01092 | 0.03175 | 0.34406 | 27.00000 | 17.00000 | 43.00000 |
| GMM_pca | entrenamiento | 1 | 70 | 5803 | 230 | 0.03963 | 0.03175 | 1.24834 | 35.00000 | 20.00000 | 50.00000 |
| KMeans_original | evaluacion_anterior_observada | 0 | 70 | 1493 | 42 | 0.02813 | 0.02650 | 1.06156 | 34.00000 | 21.00000 | 47.00000 |
| KMeans_original | evaluacion_anterior_observada | 1 | 70 | 507 | 11 | 0.02170 | 0.02650 | 0.81873 | 39.00000 | 22.00000 | 52.00000 |
| KMeans_original | nueva_evaluacion | 0 | 70 | 1524 | 45 | 0.02953 | 0.02900 | 1.01819 | 35.00000 | 22.00000 | 49.00000 |
| KMeans_original | nueva_evaluacion | 1 | 70 | 476 | 13 | 0.02731 | 0.02900 | 0.94176 | 38.00000 | 22.00000 | 52.00000 |
| GMM_original | evaluacion_anterior_observada | 0 | 70 | 731 | 11 | 0.01505 | 0.02650 | 0.56784 | 30.00000 | 19.00000 | 49.00000 |
| GMM_original | evaluacion_anterior_observada | 1 | 70 | 1269 | 42 | 0.03310 | 0.02650 | 1.24894 | 37.00000 | 23.00000 | 49.00000 |
| GMM_original | nueva_evaluacion | 0 | 70 | 715 | 9 | 0.01259 | 0.02900 | 0.43405 | 31.00000 | 20.00000 | 49.00000 |
| GMM_original | nueva_evaluacion | 1 | 70 | 1285 | 49 | 0.03813 | 0.02900 | 1.31491 | 37.00000 | 24.00000 | 51.00000 |
| KMeans_pca | evaluacion_anterior_observada | 0 | 70 | 1497 | 43 | 0.02872 | 0.02650 | 1.08393 | 34.00000 | 21.00000 | 47.00000 |
| KMeans_pca | evaluacion_anterior_observada | 1 | 70 | 503 | 10 | 0.01988 | 0.02650 | 0.75022 | 39.00000 | 22.00000 | 52.00000 |
| KMeans_pca | nueva_evaluacion | 0 | 70 | 1529 | 45 | 0.02943 | 0.02900 | 1.01486 | 35.00000 | 22.00000 | 49.00000 |
| KMeans_pca | nueva_evaluacion | 1 | 70 | 471 | 13 | 0.02760 | 0.02900 | 0.95175 | 37.00000 | 22.00000 | 52.00000 |
| GMM_pca | evaluacion_anterior_observada | 0 | 70 | 567 | 8 | 0.01411 | 0.02650 | 0.53243 | 28.00000 | 19.00000 | 43.00000 |
| GMM_pca | evaluacion_anterior_observada | 1 | 70 | 1433 | 45 | 0.03140 | 0.02650 | 1.18501 | 37.00000 | 23.00000 | 51.00000 |
| GMM_pca | nueva_evaluacion | 0 | 70 | 529 | 10 | 0.01890 | 0.02900 | 0.65185 | 30.00000 | 20.00000 | 44.00000 |
| GMM_pca | nueva_evaluacion | 1 | 70 | 1471 | 48 | 0.03263 | 0.02900 | 1.12520 | 38.00000 | 23.50000 | 52.00000 |

### Contraste principal y comparación de configuraciones

| configuration | split | cluster | threshold | n_profile | high_count | profile_rate | rest_rate | global_rate | lift | rate_difference | diff_low | diff_high | lift_low | lift_high | artist_components |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| KMeans_original | nueva_evaluacion | 0 | 70 | 1524 | 45 | 0.02953 | 0.02731 | 0.02900 | 1.01819 | 0.00222 | -0.01382 | 0.01788 | 0.88461 | 1.14886 | 1747 |
| GMM_original | nueva_evaluacion | 1 | 70 | 1285 | 49 | 0.03813 | 0.01259 | 0.02900 | 1.31491 | 0.02554 | 0.01327 | 0.03888 | 1.17193 | 1.45819 | 1747 |
| KMeans_pca | nueva_evaluacion | 0 | 70 | 1529 | 45 | 0.02943 | 0.02760 | 0.02900 | 1.01486 | 0.00183 | -0.01456 | 0.01764 | 0.88156 | 1.14460 | 1747 |
| GMM_pca | nueva_evaluacion | 1 | 70 | 1471 | 48 | 0.03263 | 0.01890 | 0.02900 | 1.12520 | 0.01373 | -0.00162 | 0.02817 | 0.98458 | 1.25067 | 1747 |

Intervalos percentiles de 2.000 remuestreos por componentes de artistas colaboradores; cada unidad se conserva completa. Son condicionales a los modelos y perfiles elegidos y no incluyen toda la incertidumbre de volver a entrenar. Las cuatro configuraciones comparten canciones y no son cuatro confirmaciones independientes; solo la configuración principal define el contraste primario. Los análisis restantes son exploratorios.

![Lift y su incertidumbre en la evaluación nueva](figuras/lift_popularidad.png)

## 4. Qué características distinguen los perfiles candidatos

Las tablas usan medianas en unidades originales y contraste perfil−resto. La diferencia estandarizada solo ordena atributos descriptivos; no es un coeficiente causal ni una prueba de importancia predictiva. El perfil se define por todas las variables, no por una sola regla musical.

| configuration | cluster | variable | profile_median | rest_median | difference | standardized_difference |
| --- | --- | --- | --- | --- | --- | --- |
| KMeans_pca | 0 | acousticness | 0.07930 | 0.81850 | -0.73920 | -2.20204 |
| KMeans_pca | 0 | energy | 0.76200 | 0.29900 | 0.46300 | 1.81470 |
| KMeans_pca | 0 | loudness | -6.14200 | -13.01800 | 6.87600 | 1.34481 |
| KMeans_pca | 0 | valence | 0.53250 | 0.26100 | 0.27150 | 1.03904 |
| KMeans_pca | 0 | danceability | 0.61000 | 0.46800 | 0.14200 | 0.80429 |
| KMeans_pca | 0 | tempo | 125.00000 | 108.40100 | 16.59900 | 0.56058 |
| KMeans_pca | 0 | duration_ms | 214889.00000 | 200413.00000 | 14476.00000 | 0.14421 |
| KMeans_pca | 0 | speechiness | 0.05460 | 0.03930 | 0.01530 | 0.13304 |
| KMeans_pca | 0 | liveness | 0.14100 | 0.11700 | 0.02400 | 0.12449 |
| KMeans_pca | 0 | instrumentalness | 0.00002 | 0.00516 | -0.00514 | -0.01598 |

![Características del perfil candidato principal](figuras/rasgos_popularidad.png)

### Perfiles candidatos de las cuatro configuraciones

| configuration | cluster | variable | profile_median | rest_median | difference | standardized_difference |
| --- | --- | --- | --- | --- | --- | --- |
| KMeans_original | 0 | acousticness | 0.07840 | 0.81700 | -0.73860 | -2.20025 |
| KMeans_original | 0 | energy | 0.76300 | 0.30300 | 0.46000 | 1.80294 |
| KMeans_original | 0 | loudness | -6.13400 | -12.94000 | 6.80600 | 1.33112 |
| KMeans_original | 0 | valence | 0.53300 | 0.26200 | 0.27100 | 1.03713 |
| KMeans_original | 0 | danceability | 0.61000 | 0.47100 | 0.13900 | 0.78729 |
| KMeans_original | 0 | tempo | 125.00100 | 108.86950 | 16.13150 | 0.54479 |
| KMeans_original | 0 | duration_ms | 214813.00000 | 201293.00000 | 13520.00000 | 0.13469 |
| KMeans_original | 0 | speechiness | 0.05470 | 0.03930 | 0.01540 | 0.13391 |
| KMeans_original | 0 | liveness | 0.14100 | 0.11700 | 0.02400 | 0.12449 |
| KMeans_original | 0 | instrumentalness | 0.00002 | 0.00504 | -0.00502 | -0.01561 |
| GMM_original | 1 | instrumentalness | 0.00000 | 0.55900 | -0.55900 | -1.73725 |
| GMM_original | 1 | valence | 0.52500 | 0.31500 | 0.21000 | 0.80368 |
| GMM_original | 1 | loudness | -6.58800 | -9.09800 | 2.51000 | 0.49091 |
| GMM_original | 1 | acousticness | 0.21700 | 0.09650 | 0.12050 | 0.35896 |
| GMM_original | 1 | danceability | 0.58900 | 0.54300 | 0.04600 | 0.26054 |
| GMM_original | 1 | duration_ms | 207832.00000 | 227000.00000 | -19168.00000 | -0.19095 |
| GMM_original | 1 | liveness | 0.13700 | 0.12200 | 0.01500 | 0.07781 |
| GMM_original | 1 | energy | 0.67900 | 0.66000 | 0.01900 | 0.07447 |
| GMM_original | 1 | speechiness | 0.04930 | 0.04820 | 0.00110 | 0.00957 |
| GMM_original | 1 | tempo | 122.15250 | 122.02600 | 0.12650 | 0.00427 |
| KMeans_pca | 0 | acousticness | 0.07930 | 0.81850 | -0.73920 | -2.20204 |
| KMeans_pca | 0 | energy | 0.76200 | 0.29900 | 0.46300 | 1.81470 |
| KMeans_pca | 0 | loudness | -6.14200 | -13.01800 | 6.87600 | 1.34481 |
| KMeans_pca | 0 | valence | 0.53250 | 0.26100 | 0.27150 | 1.03904 |
| KMeans_pca | 0 | danceability | 0.61000 | 0.46800 | 0.14200 | 0.80429 |
| KMeans_pca | 0 | tempo | 125.00000 | 108.40100 | 16.59900 | 0.56058 |
| KMeans_pca | 0 | duration_ms | 214889.00000 | 200413.00000 | 14476.00000 | 0.14421 |
| KMeans_pca | 0 | speechiness | 0.05460 | 0.03930 | 0.01530 | 0.13304 |
| KMeans_pca | 0 | liveness | 0.14100 | 0.11700 | 0.02400 | 0.12449 |
| KMeans_pca | 0 | instrumentalness | 0.00002 | 0.00516 | -0.00514 | -0.01598 |
| GMM_pca | 1 | liveness | 0.12000 | 0.28100 | -0.16100 | -0.83512 |
| GMM_pca | 1 | valence | 0.48900 | 0.38500 | 0.10400 | 0.39801 |
| GMM_pca | 1 | energy | 0.64900 | 0.74400 | -0.09500 | -0.37235 |
| GMM_pca | 1 | acousticness | 0.21900 | 0.10600 | 0.11300 | 0.33662 |
| GMM_pca | 1 | speechiness | 0.04450 | 0.07320 | -0.02870 | -0.24956 |
| GMM_pca | 1 | tempo | 120.22800 | 125.50250 | -5.27450 | -0.17813 |
| GMM_pca | 1 | danceability | 0.58400 | 0.55700 | 0.02700 | 0.15293 |
| GMM_pca | 1 | duration_ms | 209910.00000 | 224017.00000 | -14107.00000 | -0.14053 |
| GMM_pca | 1 | loudness | -7.03500 | -7.56900 | 0.53400 | 0.10444 |
| GMM_pca | 1 | instrumentalness | 0.00002 | 0.02200 | -0.02198 | -0.06831 |

## 5. Sensibilidad y distribución completa

| configuration | split | cluster | threshold | n_profile | high_count | profile_rate | rest_rate | global_rate | lift | rate_difference | diff_low | diff_high | lift_low | lift_high | artist_components |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| KMeans_original | nueva_evaluacion | 0 | 70 | 1524 | 45 | 0.02953 | 0.02731 | 0.02900 | 1.01819 | 0.00222 | -0.01382 | 0.01788 | 0.88461 | 1.14886 | 1747 |
| KMeans_original | nueva_evaluacion | 0 | 60 | 1524 | 175 | 0.11483 | 0.12815 | 0.11800 | 0.97313 | -0.01332 | -0.04693 | 0.02062 | 0.90504 | 1.04156 | 1747 |
| KMeans_original | nueva_evaluacion | 0 | 80 | 1524 | 6 | 0.00394 | 0.00630 | 0.00450 | 0.87489 | -0.00237 | -0.01086 | 0.00438 | 0.42881 | 1.31383 | 1747 |
| GMM_original | nueva_evaluacion | 1 | 70 | 1285 | 49 | 0.03813 | 0.01259 | 0.02900 | 1.31491 | 0.02554 | 0.01327 | 0.03888 | 1.17193 | 1.45819 | 1747 |
| GMM_original | nueva_evaluacion | 1 | 60 | 1285 | 172 | 0.13385 | 0.08951 | 0.11800 | 1.13434 | 0.04434 | 0.01513 | 0.07412 | 1.04648 | 1.22205 | 1747 |
| GMM_original | nueva_evaluacion | 1 | 80 | 1285 | 8 | 0.00623 | 0.00140 | 0.00450 | 1.38348 | 0.00483 | -0.00037 | 0.00986 | 0.96249 | 1.60000 | 1747 |
| KMeans_pca | nueva_evaluacion | 0 | 70 | 1529 | 45 | 0.02943 | 0.02760 | 0.02900 | 1.01486 | 0.00183 | -0.01456 | 0.01764 | 0.88156 | 1.14460 | 1747 |
| KMeans_pca | nueva_evaluacion | 0 | 60 | 1529 | 175 | 0.11445 | 0.12951 | 0.11800 | 0.96995 | -0.01506 | -0.04882 | 0.01903 | 0.90232 | 1.03791 | 1747 |
| KMeans_pca | nueva_evaluacion | 0 | 80 | 1529 | 6 | 0.00392 | 0.00637 | 0.00450 | 0.87203 | -0.00245 | -0.01099 | 0.00433 | 0.42742 | 1.30895 | 1747 |
| GMM_pca | nueva_evaluacion | 1 | 70 | 1471 | 48 | 0.03263 | 0.01890 | 0.02900 | 1.12520 | 0.01373 | -0.00162 | 0.02817 | 0.98458 | 1.25067 | 1747 |
| GMM_pca | nueva_evaluacion | 1 | 60 | 1471 | 202 | 0.13732 | 0.06427 | 0.11800 | 1.16374 | 0.07305 | 0.04375 | 0.10008 | 1.09827 | 1.22243 | 1747 |
| GMM_pca | nueva_evaluacion | 1 | 80 | 1471 | 7 | 0.00476 | 0.00378 | 0.00450 | 1.05748 | 0.00098 | -0.00599 | 0.00670 | 0.58541 | 1.37311 | 1747 |

La sensibilidad mantiene el perfil candidato identificado con umbral 70. Revisar si el signo de la diferencia se conserva con 60 y 80 y cuán amplios son sus intervalos; no elegir un umbral después de ver los resultados. Con pocos casos ≥80 la incertidumbre puede ser grande.

![Popularidad completa por perfil](figuras/distribucion_popularidad.png)

Las cajas muestran mediana y dispersión: una proporción alta puede coexistir con muchas canciones de baja popularidad. La superposición impide convertir un perfil en garantía individual.

## 6. Respuesta y límites

No se confirma una mayor concentración en la nueva evaluación: el intervalo de la diferencia incluye cero.

La respuesta debe citar el contraste de KMeans_pca, perfil 0: tasa 2.94%, lift 1.01, diferencia +0.18 pp e intervalo [-1.46, +1.76]. Si no se confirma, no se afirma que no exista ningún patrón posible: solo que este candidato y este diseño no lo confirman.

El análisis no distingue causas de popularidad: promoción, artista, idioma, exposición en playlists y momento del lanzamiento pueden explicar asociaciones. Los atributos agregados no describen melodía, letra o estructura verso/estribillo. No se recomienda una receta de producción ni se afirma un porcentaje de precisión de éxitos.

## 7. Experimento obligatorio de clustering y PCA

### Método: Datos y preparación sin fuga

Fuente: Pandya, Spotify Tracks Dataset, Hugging Face. Licencia declarada en su ficha: bsd; no se atribuye una variante BSD no especificada. Se utilizan datos tabulares y no se distribuye audio. La popularidad es la registrada en el archivo, no reproducciones actuales.

| variable | unidad | faltantes_fuente | faltantes_train |
| --- | --- | --- | --- |
| danceability | 0–1 | 0 | 0 |
| energy | 0–1 | 0 | 0 |
| loudness | dB | 0 | 0 |
| speechiness | 0–1 | 0 | 0 |
| acousticness | 0–1 | 0 | 0 |
| instrumentalness | 0–1 | 0 | 0 |
| liveness | 0–1 | 0 | 0 |
| valence | 0–1 | 0 | 0 |
| tempo | BPM | 0 | 21 |
| duration_ms | ms | 0 | 0 |

| etapa | n |
| --- | --- |
| raw_rows | 114000 |
| unique_rows | 89741 |
| development | 8000 |
| inner_fit | 6162 |
| validation | 1838 |
| eligible_holdout | 25888 |
| holdout | 2000 |

Se conserva la primera aparición por ID sin seleccionar por popularidad. Variables fuera de rango, valores no finitos y tempo/duración no positivos pasan a faltantes. Medianas y transformaciones se ajustan solo con el subconjunto de ajuste, y se reajustan en desarrollo completo una vez congeladas las elecciones.

Los grupos de artistas unen colaboraciones transitivamente; dividir solo por cadena completa de artista dejaría fugas. En la prueba adicional se excluyen IDs previos, artistas individuales de toda la muestra anterior y vectores acústicos iguales tras redondeo a siete decimales. Esto no identifica todas las versiones semánticamente duplicadas ni constituye una muestra temporal o un dataset externo.

| variable | count | mean | std | min | 25% | 50% | 75% | max |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| danceability | 8000.00000 | 0.56437 | 0.17655 | 0.00000 | 0.45400 | 0.57850 | 0.69400 | 0.98000 |
| energy | 8000.00000 | 0.63441 | 0.25514 | 0.00002 | 0.45700 | 0.67500 | 0.85200 | 1.00000 |
| loudness | 8000.00000 | -8.49959 | 5.11298 | -40.60600 | -10.40800 | -7.17650 | -5.12575 | 0.68100 |
| speechiness | 8000.00000 | 0.08823 | 0.11500 | 0.00000 | 0.03590 | 0.04880 | 0.08550 | 0.95900 |
| acousticness | 8000.00000 | 0.32615 | 0.33569 | 0.00000 | 0.01767 | 0.18900 | 0.61725 | 0.99600 |
| instrumentalness | 8000.00000 | 0.17058 | 0.32177 | 0.00000 | 0.00000 | 0.00006 | 0.08968 | 1.00000 |
| liveness | 8000.00000 | 0.21466 | 0.19279 | 0.00986 | 0.09810 | 0.13100 | 0.27200 | 0.99100 |
| valence | 8000.00000 | 0.47440 | 0.26130 | 0.00000 | 0.26100 | 0.46500 | 0.68700 | 0.99100 |
| tempo | 7979.00000 | 122.11500 | 29.61063 | 35.79000 | 99.35450 | 122.08100 | 140.05800 | 219.97100 |
| duration_ms | 8000.00000 | 227864.00300 | 100381.80579 | 13386.00000 | 172054.75000 | 212631.00000 | 262989.50000 | 2646866.00000 |

![Distribuciones en unidades originales](figuras/distribuciones.png)

| variable | skew_raw | skew_selected | iqr_outlier_fraction |
| --- | --- | --- | --- |
| danceability | -0.43405 | -0.43405 | 0.00762 |
| energy | -0.55321 | -0.55321 | 0.00000 |
| loudness | -1.91674 | -1.91674 | 0.05187 |
| speechiness | 4.44129 | 4.44129 | 0.12200 |
| acousticness | 0.66815 | 0.66815 | 0.00000 |
| instrumentalness | 1.59588 | 1.59588 | 0.21838 |
| liveness | 2.09403 | 2.09403 | 0.07925 |
| valence | 0.09873 | 0.09873 | 0.00000 |
| tempo | 0.28609 | 0.28648 | 0.00525 |
| duration_ms | 4.70301 | 4.70301 | 0.04600 |

Los extremos IQR se describen, no se eliminan automáticamente: instrumentalidad o habla elevadas pueden ser legítimas. Yeo-Johnson transforma las distribuciones marginales y después estandariza; no garantiza gaussianidad conjunta ni mejores agrupamientos. StandardScaler iguala escalas, pero no elimina asimetría.

![Correlaciones de entrenamiento](figuras/correlaciones.png)

energy/loudness: r=+0.753; energy/acousticness: r=-0.727; loudness/acousticness: r=-0.572. Las correlaciones anticipan redundancia parcial, no autorizan a descartar información sin comparar.

### Método: Protocolo y selección

El protocolo se escribió antes de ejecutar la nueva búsqueda y se conserva con huella SHA-256. Esta revisión es exploratoria y está informada por la versión anterior; no se presenta como prerregistro externo. No se usa la prueba adicional para seleccionar. El test anterior ya observado tampoco selecciona.

| preparacion | silhouette_validacion_media |
| --- | --- |
| standard | 0.19514 |
| yeo_johnson | 0.19669 |

Regla común: maximizar Silhouette en validación, calculado siempre en las diez variables estandarizadas por el escalador de referencia. Se exige al menos 2 % por grupo en ajuste y validación. Dentro de 0,005 del máximo se prefiere menor K; a igualdad de K, menor BIC para GMM. Para cambiar de preparación se exige ganancia media superior a 0,005 en las cuatro configuraciones. Es una regla explícita de parsimonia, no una prueba de significación.

BIC y AIC se calculan como diagnósticos de densidad, pero no se priorizan sobre la utilidad de segmentación. Este cambio de objetivo respecto a la versión anterior se declara; no prueba que la densidad GMM ahora esté mejor ajustada. BIC no se compara entre espacios o transformaciones diferentes. La geometría común favorece por definición conservar la representación estandarizada original.

| preprocessing | model | space | k | covariance | val_sil_common | bic | min_train_fraction | min_val_fraction |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| standard | KMeans | original | 2 | — | 0.23418 | — | 0.24862 | 0.25408 |
| standard | GMM | original | 2 | full | 0.13091 | 114685.78702 | 0.35232 | 0.31937 |
| standard | KMeans | pca | 2 | — | 0.23521 | — | 0.24684 | 0.25245 |
| standard | GMM | pca | 2 | diag | 0.18028 | 125994.22377 | 0.35638 | 0.37486 |
| yeo_johnson | KMeans | original | 2 | — | 0.18759 | — | 0.34826 | 0.37758 |
| yeo_johnson | GMM | original | 2 | diag | 0.21773 | 164936.33045 | 0.23710 | 0.25082 |
| yeo_johnson | KMeans | pca | 2 | — | 0.18540 | — | 0.35378 | 0.38139 |
| yeo_johnson | GMM | pca | 2 | diag | 0.19605 | 128173.57834 | 0.32652 | 0.35201 |

![Selección standard/KMeans/original](figuras/busqueda_standard_KMeans_original.png)

![Selección standard/KMeans/pca](figuras/busqueda_standard_KMeans_pca.png)

![Selección standard/GMM/original](figuras/busqueda_standard_GMM_original.png)

![Selección standard/GMM/pca](figuras/busqueda_standard_GMM_pca.png)

![Selección yeo_johnson/KMeans/original](figuras/busqueda_yeo_johnson_KMeans_original.png)

![Selección yeo_johnson/KMeans/pca](figuras/busqueda_yeo_johnson_KMeans_pca.png)

![Selección yeo_johnson/GMM/original](figuras/busqueda_yeo_johnson_GMM_original.png)

![Selección yeo_johnson/GMM/pca](figuras/busqueda_yeo_johnson_GMM_pca.png)

### Método: PCA e interpretación

Umbral fijado en 90 %: se retienen 7 componentes y 90.81%. PC1+PC2 muestran solo 44.10%; no son todo el espacio del modelo.

![Varianza acumulada de PCA](figuras/varianza_pca.png)

| variable | PC1 | PC2 |
| --- | --- | --- |
| danceability | 0.27306 | 0.43502 |
| energy | 0.49766 | -0.29156 |
| loudness | 0.51210 | -0.09364 |
| speechiness | 0.10563 | 0.14135 |
| acousticness | -0.42762 | 0.35939 |
| instrumentalness | -0.28995 | -0.33153 |
| liveness | 0.05869 | -0.08664 |
| valence | 0.31904 | 0.46178 |
| tempo | 0.17471 | -0.24383 |
| duration_ms | -0.04090 | -0.42157 |

PC1: loudness (+0.512), energy (+0.498), acousticness (-0.428), valence (+0.319). El componente contrasta los atributos positivos y negativos indicados. Si se selecciona Yeo-Johnson, las cargas corresponden a características transformadas, no a relaciones lineales con las unidades físicas originales. El signo global es arbitrario.

PC2: valence (+0.462), danceability (+0.435), duration_ms (-0.422), acousticness (+0.359). El componente contrasta los atributos positivos y negativos indicados. Si se selecciona Yeo-Johnson, las cargas corresponden a características transformadas, no a relaciones lineales con las unidades físicas originales. El signo global es arbitrario.

PC1 contrapone intensidad y nivel sonoro (energy y loudness) frente a carácter acústico (acousticness). En términos musicales, resume un eje de sonido más intenso/producido frente a textura más acústica; no clasifica automáticamente géneros ni calidad.

PC2 contrapone valencia y bailabilidad frente a instrumentalidad y duración. Describe un eje de positividad sonora y ritmo bailable frente a formatos más largos o instrumentales. Son interpretaciones descriptivas de las cargas observadas, no emociones del oyente ni una receta de éxito.

### Método: Tabla comparativa obligatoria y comparación justa

Original significa diez características preparadas, sin PCA. Native usa la geometría de cada ajuste; reference_original siempre utiliza las diez características con StandardScaler de referencia. Solo estas últimas filas permiten comparar separaciones en la misma geometría. Se incluyen entrenamiento y prueba, hiperparámetros, grupos, tres métricas, tiempos y ARI. Ruido=0 porque ambos asignan todas las canciones; no equivale a detectar ausencia de anomalías.

| model | space | preprocessing | split | evaluation_space | hyperparameters | groups | noise_pct | fit_seconds | predict_seconds | ari_vs_original | silhouette | davies_bouldin | calinski_harabasz |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| KMeans | original | standard | train | native | {"k": 2, "covariance": "NA"} | 2 | 0.00000 | 0.13203 | 0.00056 | — | 0.24933 | 1.68308 | 1947.65054 |
| KMeans | original | standard | train | reference_original | {"k": 2, "covariance": "NA"} | 2 | 0.00000 | 0.13203 | 0.00056 | — | 0.24933 | 1.68308 | 1947.65054 |
| KMeans | original | standard | test | native | {"k": 2, "covariance": "NA"} | 2 | 0.00000 | 0.13203 | 0.00056 | — | 0.21839 | 1.76828 | 389.78056 |
| KMeans | original | standard | test | reference_original | {"k": 2, "covariance": "NA"} | 2 | 0.00000 | 0.13203 | 0.00056 | — | 0.21839 | 1.76828 | 389.78056 |
| GMM | original | standard | train | native | {"k": 2, "covariance": "full"} | 2 | 0.00000 | 0.50247 | 0.00117 | — | 0.12461 | 3.03457 | 735.53684 |
| GMM | original | standard | train | reference_original | {"k": 2, "covariance": "full"} | 2 | 0.00000 | 0.50247 | 0.00117 | — | 0.12461 | 3.03457 | 735.53684 |
| GMM | original | standard | test | native | {"k": 2, "covariance": "full"} | 2 | 0.00000 | 0.50247 | 0.00117 | — | 0.11776 | 3.15014 | 159.57386 |
| GMM | original | standard | test | reference_original | {"k": 2, "covariance": "full"} | 2 | 0.00000 | 0.50247 | 0.00117 | — | 0.11776 | 3.15014 | 159.57386 |
| KMeans | pca | standard | train | native | {"k": 2, "covariance": "NA"} | 2 | 0.00000 | 0.12457 | 0.00052 | 0.98252 | 0.27031 | 1.55983 | 2194.56123 |
| KMeans | pca | standard | train | reference_original | {"k": 2, "covariance": "NA"} | 2 | 0.00000 | 0.12457 | 0.00052 | 0.98252 | 0.24967 | 1.67786 | 1947.30985 |
| KMeans | pca | standard | test | native | {"k": 2, "covariance": "NA"} | 2 | 0.00000 | 0.12457 | 0.00052 | 0.98304 | 0.23908 | 1.63408 | 436.47928 |
| KMeans | pca | standard | test | reference_original | {"k": 2, "covariance": "NA"} | 2 | 0.00000 | 0.12457 | 0.00052 | 0.98304 | 0.22025 | 1.76713 | 389.69274 |
| GMM | pca | standard | train | native | {"k": 2, "covariance": "diag"} | 2 | 0.00000 | 0.52224 | 0.00053 | 0.11836 | 0.19174 | 3.36682 | 569.54647 |
| GMM | pca | standard | train | reference_original | {"k": 2, "covariance": "diag"} | 2 | 0.00000 | 0.52224 | 0.00053 | 0.11836 | 0.17610 | 3.55760 | 515.90654 |
| GMM | pca | standard | test | native | {"k": 2, "covariance": "diag"} | 2 | 0.00000 | 0.52224 | 0.00053 | 0.10868 | 0.19040 | 3.24735 | 144.15876 |
| GMM | pca | standard | test | reference_original | {"k": 2, "covariance": "diag"} | 2 | 0.00000 | 0.52224 | 0.00053 | 0.10868 | 0.17461 | 3.44347 | 130.81221 |

Silhouette: mayor mejor, cohesión frente a separación. Davies-Bouldin: menor mejor, similitud entre grupos. Calinski-Harabasz: mayor mejor, dispersión entre grupos respecto a dispersión interna. Favorecen agrupamientos compactos y no son medidas de gusto o éxito. Silhouette usa hasta 2.000 observaciones con semilla fija; las otras métricas usan el conjunto completo.

### Método: Estabilidad y costo

| model | space | kind | mean | min | max |
| --- | --- | --- | --- | --- | --- |
| GMM | original | seed | 1.00000 | 1.00000 | 1.00000 |
| GMM | original | subsample | 0.99197 | 0.98797 | 0.99598 |
| GMM | pca | seed | 1.00000 | 1.00000 | 1.00000 |
| GMM | pca | subsample | 0.94811 | 0.93066 | 0.95669 |
| KMeans | original | seed | 0.99433 | 0.98938 | 1.00000 |
| KMeans | original | subsample | 0.98795 | 0.98301 | 0.99360 |
| KMeans | pca | seed | 0.99681 | 0.99362 | 1.00000 |
| KMeans | pca | subsample | 0.98971 | 0.98298 | 0.99787 |

Cuatro semillas y cuatro submuestras de 80 % por configuración; ARI entre pares sobre las mismas canciones de prueba. Transformación y PCA permanecen fijos: mide estabilidad condicional de los modelos. No se selecciona con esta prueba. La incertidumbre de toda la preparación requiere remuestrear el pipeline completo.

| model | space | fit_seconds_median | fit_seconds_min | fit_seconds_max | predict_seconds_median | predict_seconds_min | predict_seconds_max |
| --- | --- | --- | --- | --- | --- | --- | --- |
| GMM | original | 0.79359 | 0.58805 | 0.90425 | 0.00209 | 0.00150 | 0.00228 |
| GMM | pca | 0.79011 | 0.48696 | 0.89467 | 0.00338 | 0.00065 | 0.00485 |
| KMeans | original | 0.11793 | 0.11669 | 0.12391 | 0.00051 | 0.00050 | 0.00052 |
| KMeans | pca | 0.30821 | 0.24680 | 0.45715 | 0.00074 | 0.00052 | 0.00313 |

Preparación final compartida (incluye representación de referencia y PCA): 0.0642 s. Los tiempos repetidos de modelos excluyen búsqueda y preparación, usan un hilo numérico y no son una garantía de rendimiento en otro equipo.

### Método: Interpretación y acciones por perfil

### KMeans_original

| cluster | n | danceability | energy | loudness | speechiness | acousticness | instrumentalness | liveness | valence | tempo | duration_ms |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | 5967 | 0.61000 | 0.76300 | -6.13400 | 0.05470 | 0.07840 | 0.00002 | 0.14100 | 0.53300 | 125.00100 | 214813.00000 |
| 1 | 2033 | 0.47100 | 0.30300 | -12.94000 | 0.03930 | 0.81700 | 0.00504 | 0.11700 | 0.26200 | 108.86950 | 201293.00000 |

![Perfiles originales KMeans_original](figuras/perfiles_KMeans_original.png)

![Mapa PC1/PC2 KMeans_original](figuras/mapa_KMeans_original.png)

Grupo 0: intenso, mixto, 125.0 BPM, 3.58 min; 5967 canciones. Acción: filtrar referencias con esta combinación y contrastarlas por escucha. No prescribe una mezcla, género verdadero o público objetivo.

Grupo 1: suave, acústico, 108.9 BPM, 3.35 min; 2033 canciones. Acción: filtrar referencias con esta combinación y contrastarlas por escucha. No prescribe una mezcla, género verdadero o público objetivo.

### GMM_original

| cluster | n | danceability | energy | loudness | speechiness | acousticness | instrumentalness | liveness | valence | tempo | duration_ms |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | 2755 | 0.54300 | 0.66000 | -9.09800 | 0.04820 | 0.09650 | 0.55900 | 0.12200 | 0.31500 | 122.02600 | 227000.00000 |
| 1 | 5245 | 0.58900 | 0.67900 | -6.58800 | 0.04930 | 0.21700 | 0.00000 | 0.13700 | 0.52500 | 122.15250 | 207832.00000 |

![Perfiles originales GMM_original](figuras/perfiles_GMM_original.png)

![Mapa PC1/PC2 GMM_original](figuras/mapa_GMM_original.png)

Grupo 0: intenso, instrumental, 122.0 BPM, 3.78 min; 2755 canciones. Acción: filtrar referencias con esta combinación y contrastarlas por escucha. No prescribe una mezcla, género verdadero o público objetivo.

Grupo 1: intenso, mixto, 122.2 BPM, 3.46 min; 5245 canciones. Acción: filtrar referencias con esta combinación y contrastarlas por escucha. No prescribe una mezcla, género verdadero o público objetivo.

### KMeans_pca

| cluster | n | danceability | energy | loudness | speechiness | acousticness | instrumentalness | liveness | valence | tempo | duration_ms |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | 5990 | 0.61000 | 0.76200 | -6.14200 | 0.05460 | 0.07930 | 0.00002 | 0.14100 | 0.53250 | 125.00000 | 214889.00000 |
| 1 | 2010 | 0.46800 | 0.29900 | -13.01800 | 0.03930 | 0.81850 | 0.00516 | 0.11700 | 0.26100 | 108.40100 | 200413.00000 |

![Perfiles originales KMeans_pca](figuras/perfiles_KMeans_pca.png)

![Mapa PC1/PC2 KMeans_pca](figuras/mapa_KMeans_pca.png)

Grupo 0: intenso, mixto, 125.0 BPM, 3.58 min; 5990 canciones. Acción: filtrar referencias con esta combinación y contrastarlas por escucha. No prescribe una mezcla, género verdadero o público objetivo.

Grupo 1: suave, acústico, 108.4 BPM, 3.34 min; 2010 canciones. Acción: filtrar referencias con esta combinación y contrastarlas por escucha. No prescribe una mezcla, género verdadero o público objetivo.

### GMM_pca

| cluster | n | danceability | energy | loudness | speechiness | acousticness | instrumentalness | liveness | valence | tempo | duration_ms |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | 2197 | 0.55700 | 0.74400 | -7.56900 | 0.07320 | 0.10600 | 0.02200 | 0.28100 | 0.38500 | 125.50250 | 224017.00000 |
| 1 | 5803 | 0.58400 | 0.64900 | -7.03500 | 0.04450 | 0.21900 | 0.00002 | 0.12000 | 0.48900 | 120.22800 | 209910.00000 |

![Perfiles originales GMM_pca](figuras/perfiles_GMM_pca.png)

![Mapa PC1/PC2 GMM_pca](figuras/mapa_GMM_pca.png)

Grupo 0: intenso, mixto, 125.5 BPM, 3.73 min; 2197 canciones. Acción: filtrar referencias con esta combinación y contrastarlas por escucha. No prescribe una mezcla, género verdadero o público objetivo.

Grupo 1: intermedio, mixto, 120.2 BPM, 3.50 min; 5803 canciones. Acción: filtrar referencias con esta combinación y contrastarlas por escucha. No prescribe una mezcla, género verdadero o público objetivo.

### Distribuciones de popularidad después del agrupamiento

| model | space | split | cluster | n | median | q25 | q75 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| KMeans | original | test | 0 | 1493 | 34.00000 | 21.00000 | 47.00000 |
| KMeans | original | test | 1 | 507 | 39.00000 | 22.00000 | 52.00000 |
| KMeans | original | train | 0 | 5967 | 34.00000 | 20.00000 | 48.00000 |
| KMeans | original | train | 1 | 2033 | 29.00000 | 17.00000 | 46.00000 |
| GMM | original | test | 0 | 731 | 30.00000 | 19.00000 | 49.00000 |
| GMM | original | test | 1 | 1269 | 37.00000 | 23.00000 | 49.00000 |
| GMM | original | train | 0 | 2755 | 26.00000 | 16.00000 | 45.00000 |
| GMM | original | train | 1 | 5245 | 36.00000 | 22.00000 | 49.00000 |
| KMeans | pca | test | 0 | 1497 | 34.00000 | 21.00000 | 47.00000 |
| KMeans | pca | test | 1 | 503 | 39.00000 | 22.00000 | 52.00000 |
| KMeans | pca | train | 0 | 5990 | 34.00000 | 20.00000 | 48.00000 |
| KMeans | pca | train | 1 | 2010 | 29.00000 | 17.00000 | 46.00000 |
| GMM | pca | test | 0 | 567 | 28.00000 | 19.00000 | 43.00000 |
| GMM | pca | test | 1 | 1433 | 37.00000 | 23.00000 | 51.00000 |
| GMM | pca | train | 0 | 2197 | 27.00000 | 17.00000 | 43.00000 |
| GMM | pca | train | 1 | 5803 | 35.00000 | 20.00000 | 50.00000 |

Las medianas y cuartiles describen el archivo. Las diferencias no garantizan éxito individual ni prueban causalidad. La validación por artistas cambia la población: no se comparan sin más estas cifras con las del test anterior.

## 8. Las doce respuestas de la rúbrica

### 1. Escalado

| model | ari_scaled_unscaled | silhouette_scaled_common | silhouette_unscaled_labels_common |
| --- | --- | --- | --- |
| KMeans | 0.00238 | 0.24933 | 0.13187 |
| GMM | 0.59787 | 0.12461 | 0.12786 |

Duración en milisegundos domina distancias sin escalar frente a variables 0–1. El control conserva hiperparámetros y evalúa sus etiquetas en la misma geometría común. El ARI cuantifica el cambio de partición y evita concluir por un Silhouette medido con otra escala.

### 2. Elección de hiperparámetros

| model | space | k | covariance | val_sil_common | bic |
| --- | --- | --- | --- | --- | --- |
| KMeans | original | 2 | NA | 0.23418 | — |
| GMM | original | 2 | full | 0.13091 | 114685.78702 |
| KMeans | pca | 2 | NA | 0.23521 | — |
| GMM | pca | 2 | diag | 0.18028 | 125994.22377 |

La búsqueda y sus curvas abarcan K=2–10,12,16,20,24 y covarianzas full/diag para GMM. Se prioriza separación de validación con tamaños mínimos y parsimonia; BIC explica ajuste de densidad, distinto del objetivo de segmentación. La tabla completa conserva todos los intentos, no solo ganadores.

### 3. Sesgo de las métricas

| model | space | silhouette | davies_bouldin | calinski_harabasz |
| --- | --- | --- | --- | --- |
| KMeans | original | 0.21839 | 1.76828 | 389.78056 |
| GMM | original | 0.11776 | 3.15014 | 159.57386 |
| KMeans | pca | 0.22025 | 1.76713 | 389.69274 |
| GMM | pca | 0.17461 | 3.44347 | 130.81221 |

El objetivo euclidiano y el criterio favorecen a K-Means y a gaussianas compactas. Las nubes superpuestas en los mapas advierten que los perfiles pueden ser discretizaciones de un continuo. La proyección PC1/PC2 no prueba separación en todas las dimensiones; contrastar con estas métricas y no solo colores.

### 4. Ruido y atípicos

| variable | skew_raw | skew_selected | iqr_outlier_fraction |
| --- | --- | --- | --- |
| danceability | -0.43405 | -0.43405 | 0.00762 |
| energy | -0.55321 | -0.55321 | 0.00000 |
| loudness | -1.91674 | -1.91674 | 0.05187 |
| speechiness | 4.44129 | 4.44129 | 0.12200 |
| acousticness | 0.66815 | 0.66815 | 0.00000 |
| instrumentalness | 1.59588 | 1.59588 | 0.21838 |
| liveness | 2.09403 | 2.09403 | 0.07925 |
| valence | 0.09873 | 0.09873 | 0.00000 |
| tempo | 0.28609 | 0.28648 | 0.00525 |
| duration_ms | 4.70301 | 4.70301 | 0.04600 |

No se utilizó DBSCAN. K-Means y GMM asignan todos los puntos: ruido 0 % es una propiedad del método. Los atípicos pueden desplazar centroides y covarianzas. No se eliminan perfiles musicales válidos por IQR; se compara una transformación marginal predefinida y se describen sus límites.

### 5. Componentes principales

7 componentes, varianza 90.81%; dos primeras dimensiones 44.10%.

| variable | PC1 | PC2 |
| --- | --- | --- |
| danceability | 0.27306 | 0.43502 |
| energy | 0.49766 | -0.29156 |
| loudness | 0.51210 | -0.09364 |
| speechiness | 0.10563 | 0.14135 |
| acousticness | -0.42762 | 0.35939 |
| instrumentalness | -0.28995 | -0.33153 |
| liveness | 0.05869 | -0.08664 |
| valence | 0.31904 | 0.46178 |
| tempo | 0.17471 | -0.24383 |
| duration_ms | -0.04090 | -0.42157 |

Las mayores cargas absolutas de la sección 4 definen los contrastes acústicos; se interpretan con sus signos. La varianza retenida no es porcentaje de información musical ni de éxito explicado.

### 6. Efecto de la reducción

KMeans, prueba en geometría común: Silhouette 0.2184 → 0.2203; Davies-Bouldin 1.7683 → 1.7671; Calinski-Harabasz 389.78 → 389.69. PCA puede quitar redundancia o descartar diferencias útiles; las cifras no identifican por sí solas cuál causa actuó. Diez variables no justifican invocar automáticamente maldición de dimensionalidad.

GMM, prueba en geometría común: Silhouette 0.1178 → 0.1746; Davies-Bouldin 3.1501 → 3.4435; Calinski-Harabasz 159.57 → 130.81. PCA puede quitar redundancia o descartar diferencias útiles; las cifras no identifican por sí solas cuál causa actuó. Diez variables no justifican invocar automáticamente maldición de dimensionalidad.

### 7. Comparación justa

| model | space | evaluation_space | silhouette | davies_bouldin | calinski_harabasz |
| --- | --- | --- | --- | --- | --- |
| KMeans | original | native | 0.24933 | 1.68308 | 1947.65054 |
| KMeans | original | reference_original | 0.24933 | 1.68308 | 1947.65054 |
| GMM | original | native | 0.12461 | 3.03457 | 735.53684 |
| GMM | original | reference_original | 0.12461 | 3.03457 | 735.53684 |
| KMeans | pca | native | 0.27031 | 1.55983 | 2194.56123 |
| KMeans | pca | reference_original | 0.24967 | 1.67786 | 1947.30985 |
| GMM | pca | native | 0.19174 | 3.36682 | 569.54647 |
| GMM | pca | reference_original | 0.17610 | 3.55760 | 515.90654 |

Comparar Native original con Native PCA mezcla geometrías. La conclusión de separación utiliza reference_original. Cuando las conclusiones difieren, se prioriza esta geometría declarada y se reconoce el sesgo a favor de preservarla.

### 8. Cambio de asignaciones

| model | split | ari_vs_original |
| --- | --- | --- |
| KMeans | train | 0.98252 |
| KMeans | test | 0.98304 |
| GMM | train | 0.11836 |
| GMM | test | 0.10868 |

ARI=1 implica particiones equivalentes aun con etiquetas permutadas; cercano a cero es acuerdo compatible con azar. Puede ser negativo. Se compara el mismo conjunto en cada fila y no popularidad o género.

### 9. Estabilidad

| model | space | kind | mean | min | max |
| --- | --- | --- | --- | --- | --- |
| GMM | original | seed | 1.00000 | 1.00000 | 1.00000 |
| GMM | original | subsample | 0.99197 | 0.98797 | 0.99598 |
| GMM | pca | seed | 1.00000 | 1.00000 | 1.00000 |
| GMM | pca | subsample | 0.94811 | 0.93066 | 0.95669 |
| KMeans | original | seed | 0.99433 | 0.98938 | 1.00000 |
| KMeans | original | subsample | 0.98795 | 0.98301 | 0.99360 |
| KMeans | pca | seed | 0.99681 | 0.99362 | 1.00000 |
| KMeans | pca | subsample | 0.98971 | 0.98298 | 0.99787 |

En original, mayor ARI medio condicional: GMM=0.9960; KMeans=0.9911. K-Means puede variar por centroides iniciales; GMM añade sensibilidad de covarianzas y máximos locales. Un ARI alto no prueba que los grupos sean verdaderos.

En pca, mayor ARI medio condicional: KMeans=0.9933; GMM=0.9741. K-Means puede variar por centroides iniciales; GMM añade sensibilidad de covarianzas y máximos locales. Un ARI alto no prueba que los grupos sean verdaderos.

### 10. Costo computacional

| model | space | fit_seconds_median | fit_seconds_min | fit_seconds_max | predict_seconds_median | predict_seconds_min | predict_seconds_max |
| --- | --- | --- | --- | --- | --- | --- | --- |
| GMM | original | 0.79359 | 0.58805 | 0.90425 | 0.00209 | 0.00150 | 0.00228 |
| GMM | pca | 0.79011 | 0.48696 | 0.89467 | 0.00338 | 0.00065 | 0.00485 |
| KMeans | original | 0.11793 | 0.11669 | 0.12391 | 0.00051 | 0.00050 | 0.00052 |
| KMeans | pca | 0.30821 | 0.24680 | 0.45715 | 0.00074 | 0.00052 | 0.00313 |

Con 100 veces más observaciones no se extrapolan segundos ciegamente. K-Means escala aproximadamente O(n·K·d·iteraciones); GMM full añade operaciones de covarianza O(n·K·d²) y factorización O(K·d³) por iteración. Reducir d puede ayudar a GMM, pero depende también de convergencia. Silhouette completo tiene costo cuadrático en n; mantener muestreo. Incluir ajuste/transformación PCA antes de afirmar ahorro total.

### 11. Visualización no lineal

No se ejecutó UMAP ni t-SNE: son opcionales. PCA muestra 44.10% en dos ejes y no todo el espacio. Islas en una visualización no lineal hipotética no demostrarían grupos naturales. t-SNE altera distancias globales y densidades, depende de parámetros y no es entrada de este clustering.

### 12. Recomendación final

Para la pregunta de popularidad, el contraste principal de KMeans_pca da lift 1.01 e IC95 de diferencia [-1.46, +1.76] pp. No se confirma una mayor concentración en la nueva evaluación: el intervalo de la diferencia incluye cero. No se recomienda convertir el perfil en regla comercial ni escoger otra configuración porque produzca una asociación más favorable. La recomendación geométrica que sigue se refiere a la calidad de agrupamiento, no a predicción de éxito.

Se recomienda provisionalmente KMeans_pca, elegido en validación con Silhouette común=0.2352; no se cambia por los resultados de prueba ni popularidad. Revisar conjuntamente las tres métricas, estabilidad, tamaños y perfiles, y reconocer que diferencias pequeñas no demuestran superioridad estadística.

Limitaciones: muestra histórica de conveniencia; exclusión por artistas modifica la población y no equivale a evaluación temporal; versiones no detectadas; características agregadas omiten melodía, letra y secciones; sin evaluación de oyentes. Con más tiempo: validación temporal/externa, remuestreo de toda la preparación, protocolo humano y medidas longitudinales de exposición/promoción.

## 9. Cierre de la presentación

Primero presentar la tasa global, la del perfil candidato y sus intervalos. Después mostrar sus rasgos acústicos y escuchar ejemplos que permitan contrastarlos. El archivo cierre_escucha.html conserva una pareja ilustrativa de canciones cercanas con popularidades distintas: sirve para explicar los límites de una asociación, no para reemplazar el contraste principal. No se incluye audio ni una supuesta estructura ganadora.

## 10. Reproducibilidad, declaración de IA y referencias

Ejecutar Proyecto_Mejorado.ipynb completo o python mejorar_proyecto.py. El núcleo ajusta los cuatro modelos y este módulo reproduce sus particiones con ARI=1 antes de estudiar popularidad. Protocolo, selección de perfiles, IDs y conteos, remuestreos, tablas y figuras acompañan la entrega. Se utilizó ChatGPT/Codex para implementación y documentación; revisar y declarar esa asistencia. No hay evaluaciones humanas inventadas ni garantía de nota.

Pandya, M. (s. f.). Spotify Tracks Dataset [Conjunto de datos]. Hugging Face. https://huggingface.co/datasets/maharshipandya/spotify-tracks-dataset

Pedregosa, F., et al. (2011). Scikit-learn: Machine learning in Python. Journal of Machine Learning Research, 12, 2825–2830. https://jmlr.org/papers/v12/pedregosa11a.html

Scikit-learn developers. (s. f.). PowerTransformer y GroupShuffleSplit [Documentación]. https://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.PowerTransformer.html ; https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.GroupShuffleSplit.html